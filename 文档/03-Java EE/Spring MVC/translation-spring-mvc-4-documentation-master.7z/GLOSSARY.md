## 模型
21.1 model

## 视图
21.1 view

## 处理器方法
21.1 handler method

## 处理器
21.1 handler

## 控制器
21.1 controller

## 命令对象
21.1 command object

## 表单返回对象
21.1 form-backing object

## 响应
21.1 response

## 视图解析器
21.1 view resolver

## 验证器
21.1.1 validator

## 会话
21.1.1 session

## scope
21.1.1 scope，不翻译

## 分发
21.2.1 dispatch，Spring的中央处理器就是这个`DispatcherServlet`，它负责的事情，就是分发(dispatch)请求

## 处理器映射
21.2.1 handler mapping

## 处理器适配器
21.2.1 handler adapter

## 处理器异常解析器
21.2.1 handler exception resolver

## 逻辑视图名
21.2.1 logical view names

## 地区信息
### 地区
21.2.1 locale(s)

## 多路
### 多部分
21.2.1 multi-parts

## 表示
representation

## 上下文
context(s)

## 内容协商
content negotiation
