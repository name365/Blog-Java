# 21.3.5 对控制器测试

`spring-test`模块对测试控制器`@Controller`提供了最原生的支持。详见[14.6 "Spring MVC测试框架"](http://docs.spring.io/spring-framework/docs/current/spring-framework-reference/html/integration-testing.html#spring-mvc-test-framework "14.6 Spring MVC Test Framework")一节。
