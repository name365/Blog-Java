-- 删除免费图床表
DROP TABLE tool_picture;